# GitHub upload guide (no Git commands needed)

1. Create a free account or sign in at https://github.com/ .
2. Visit https://github.com/new .
3. Repository name: `inequality-homicide-oecd` . Description: `Replication materials for MA Economics paper on inequality and homicide across OECD countries, 2000–2019.`
4. Choose **Public** so readers of the paper can access it. **Do not initialize it with a README, .gitignore or license**, since these files are already in your local replication folder.
5. Click **Create repository**.
6. **Unzip the downloaded replication package** on your computer. GitHub needs the extracted files and folder structure, not just the ZIP archive.
7. On the new empty repository page choose the link to upload existing files (or **Add file > Upload files**, if the repository has a file already). Drag all contents of the **inner** `inequality-homicide-oecd` folder into the upload area. Keep `code/`, `data/`, `results/`, and `paper/` intact.
8. Enter commit message `Add initial replication materials` and click **Commit changes**.
9. Return to the repository homepage and confirm that GitHub displays `README.md` and the data/code folders. Open one script or CSV to check it uploaded successfully.
10. Copy the browser URL of your repository. It will look like `https://github.com/YOUR-USERNAME/inequality-homicide-oecd` . Add this URL to your paper's Data and Code Availability statement (see below). Test it using a private/incognito browser window.

**Suggested LaTeX:**

```latex
% In the preamble if not already loaded:
\usepackage{hyperref}

% In the paper (replace YOUR-USERNAME with your actual GitHub username):
\noindent\textbf{Data and code availability.}
Replication data, R scripts, and supporting results are available at
\url{https://github.com/YOUR-USERNAME/inequality-homicide-oecd}.
```

**Before publishing:** Do not upload `.RData`, `.Rhistory`, `.Renviron`, passwords, personal messages, drafts, logs with private paths, internal work materials, or copyrighted copies of academic papers. Review the data sources' license terms and document any updates to the final code. Public repositories are visible to everyone.

**Current gap:** The processed panel with controls is still required to reproduce all controlled main-paper models. `code/00_export_saved_panel.R` helps export it if your original RStudio `df` object is available. Do not describe the repository as a *complete* replication package until this dataset is added and its scripts have been tested.
